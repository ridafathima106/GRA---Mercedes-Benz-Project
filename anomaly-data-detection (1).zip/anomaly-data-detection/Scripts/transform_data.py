import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import LabelEncoder
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import seaborn as sns
from sklearn import preprocessing
from sklearn.neighbors import LocalOutlierFactor
from sklearn.neighbors import LocalOutlierFactor
from google.cloud import storage
from datetime import datetime


import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--material_group', type=str, required=True)
parser.add_argument('--bucket_name', type=str, required=True)
parser.add_argument('--file_name', type=str, required=True)
parser.add_argument('--bucket_name_output', type=str, required=True)
parser.add_argument('--file_name_output', type=str, required=True)
args = parser.parse_args()

material_group = args.material_group
bucket_name = args.bucket_name
file_name = args.file_name
bucket_name_output = args.bucket_name_output
file_name_output = args.file_name_output

# Get a reference to the CSV file in the GCS bucket

file_path = f"gs://{bucket_name}/{file_name}"


processed_df = pd.read_csv(file_path)

mara2 = processed_df.loc[processed_df['Matl Group'] == material_group]

# Getting the count of Columns full of NULL values
summary1 = mara2.isnull().sum()
summary11 = summary1.reset_index()
summary11.columns = ['COL_NAME', 'Counts']
summary12 = summary11.loc[summary11.Counts == len(mara2), "COL_NAME"].tolist()

# Getting the count of Columns full of Zeros
summary2 = (mara2 == 0).sum()
summary21 = summary2.reset_index()
summary21.columns = ['COL_NAME', 'Counts']
summary22 = summary21.loc[summary21.Counts == len(mara2), "COL_NAME"].tolist()
summary12.extend(summary22)

# Getting the count of Columns full of Constant values
constant_cols = [e for e in mara2.columns if mara2[e].nunique() == 1]
summary12.extend(constant_cols)

# Dropping the null/0/constant columns from the mara2 df
mara3 = mara2.loc[:, [col for col in mara2.columns if col not in summary12]]

# Removing redundant columns
mara4 = mara3.drop(['Created', 'Last Chg', 'Vehicle Id', 'Material description'], axis=1)
mara4.rename(columns = {'Size/dimensions' : 'DIMS'}, inplace = True)

# Splitting the DIMS column into three different columns
mara4['DIMS'] = mara4['DIMS'].str.replace(pat = r'\s+', repl = ' ', regex=True)
mara4['DIMS'] = mara4['DIMS'].str.replace(pat = r'\s', repl = '/', regex=True)
mara4[['DIMS0', 'DIMS1', 'DIMS2']] = mara4['DIMS'].str.split('/', expand=True)
mara4.drop(['DIMS'], axis =1, inplace = True)

# Cleaning the text columns before we apply Label Encoding
mara4['Basket Id'] = mara4['Basket Id'].str.replace('\s', '', regex = True)
mara4['Assortment Class'] = mara4['Assortment Class'].str.replace('\s', '', regex = True)

mara4['Material Description'] = mara4['Material Description'].str.replace("'", "")
mara4['Material Description'] = mara4['Material Description'].str.replace('\s', '', regex = True)
mara4['Material Description'] = mara4['Material Description'].str.replace('.', '')

# Applying Feature Engineering on the "Changed By" column to show if the change was made by a User or the System
mara4['Changed by'] = np.where(mara4['Changed by'].isin(['USI0CR', 'GRSTOLL']), 1, 0)

mara41 = mara4

#mara41 = mara41.replace(np.nan,0)
mara41['ETBM'] = pd.to_numeric(mara41['ETBM'], errors='coerce')
mara41['ETBM'] = mara41['ETBM'].fillna(-99999)
mara41['ETBM'] = mara41['ETBM'].astype(int)

label_encoder = preprocessing.LabelEncoder()
mara41['ETBM'] = label_encoder.fit_transform(mara41['ETBM'])

label_encoder = preprocessing.LabelEncoder()
mara41 = mara4.copy()

mara41['ETBM'] = mara41['ETBM'].astype(str) # Convert all values in ETBM column to string
mara41['ETBM'] = label_encoder.fit_transform(mara41['ETBM'])

# Repeat for all other columns that need encoding
mara41['Complete status'] = label_encoder.fit_transform(mara41['Complete status'])
mara41['Maint. status'] = label_encoder.fit_transform(mara41['Maint. status'])
mara41['Product hierarchy'] = label_encoder.fit_transform(mara41['Product hierarchy'])
mara41['Primus Division Code'] = label_encoder.fit_transform(mara41['Primus Division Code'])
mara41['Assortment Class'] = label_encoder.fit_transform(mara41['Assortment Class'])
mara41['Basket Id'] = label_encoder.fit_transform(mara41['Basket Id'])
mara41['Material Description'] = label_encoder.fit_transform(mara41['Material Description'])
#mara41['WUn'] = label_encoder.fit_transform(mara41['WUn'])
#mara41['VUn'] = label_encoder.fit_transform(mara41['VUn'])
#mara41['Master PDC A'] = label_encoder.fit_transform(mara41['Master PDC A'])
mara41['MTyp'] = label_encoder.fit_transform(mara41['MTyp'])
#mara41['MS'] = label_encoder.fit_transform(mara41['MS'])

pd.set_option('display.max_columns', None)

mara41['DIMS0'] = np.where(mara41['DIMS0'].isnull(), 0, mara41['DIMS0'])
mara41['DIMS1'] = np.where(mara41['DIMS1'].isnull(), 0, mara41['DIMS1'])
mara41['DIMS2'] = np.where(mara41['DIMS2'].isnull(), 0, mara41['DIMS2'])

mara61 = mara41.drop('Material', axis = 1)

tsne1 = TSNE(n_components=2, verbose=1, perplexity=10, n_iter=500)
tsne_results = tsne1.fit_transform(mara61)

mara61['tsne-2d-one'] = tsne_results[:,0]
mara61['tsne-2d-two'] = tsne_results[:,1]
mara61['Material Description1'] = mara4['Material Description']

# Dropping unnecessary columns before training the model
if(len([x for x in mara61.columns.tolist() if x in ['tsne-2d-one','tsne-2d-two', 'Material Description1']]) == 3):
    mara61.drop(['tsne-2d-one','tsne-2d-two', 'Material Description1'], axis = 1, inplace = True)

# Fitting LOF Model
model1 = LocalOutlierFactor(n_neighbors = 20, metric = "manhattan", contamination = 0.1)
y_pred = model1.fit_predict(mara61)
mara61['tsne-2d-one'] = tsne_results[:,0]
mara61['tsne-2d-two'] = tsne_results[:,1]
mara61['Material Description1'] = mara4['Material Description']

mara61['Prediction'] = np.where(y_pred == -1, 'Outlier', 'Inlier')

mara4['Prediction'] = np.where(y_pred == -1, 'Outlier', 'Inlier')
mara4['X'] = mara61['tsne-2d-one']
mara4['Y'] = mara61['tsne-2d-two']


path_output = file_name_output + material_group + '.csv'

file_path = f"gs://{bucket_name_output}/{path_output}"

mara4.to_csv(file_path, sep='\t', index=False)
