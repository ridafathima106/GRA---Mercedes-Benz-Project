import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objs as go
import plotly.offline as pyo
import random
import plotly.subplots
from google.cloud import storage
import plotly.io as pio


import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--material_group', type=str, required=True)
parser.add_argument('--bucket_name_output', type=str, required=True)
parser.add_argument('--file_name_output', type=str, required=True)

args = parser.parse_args()
material_group = args.material_group
bucket_name_output = args.bucket_name_output
file_name_output = args.file_name_output

path_output = file_name_output + material_group + '.csv'
file_path = f"gs://{bucket_name_output}/{path_output}"

# Load data
data = pd.read_csv(file_path, sep='\t')
data = data[['Material', 'Changed by', 'Net Weight', 'Volume', 'Material Description', 'DIMS0', 'DIMS1', 'DIMS2', 'Prediction']]

# Define function to add color to outlier rows
def highlight_outliers(s):
    return ['background-color: lightcoral' if v == 'Outlier' else 'background-color: none' for v in s]

# Apply highlight_outliers function to entire DataFrame and display with red rows
fig3 = data.style.apply(highlight_outliers, axis=1)

# Generate list of random numbers between 0 and 0.2
noise = [random.uniform(0, 0.2) for _ in range(len(data))]

# Add noise as a new column to data
data['Noise'] = noise

# Create scatter plot with outlier points as light red and inlier points as blue
fig1 = px.scatter(data, x='Noise', y=None, color='Prediction', color_discrete_map={'Outlier': 'lightcoral', 'Inlier': 'blue'},
                 hover_data={'Material': True})

# Update layout
fig1.update_layout(title='Inliers and Outliers', xaxis_title='', yaxis_title='')

# Count the number of inliers and outliers
counts = data['Prediction'].value_counts()

# Create the pie chart
fig2 = px.pie(counts, values=counts.values, names=counts.index, color=counts.index, 
             color_discrete_map={'Outlier': 'lightcoral', 'Inlier': 'blue'})

# Set the title
fig2.update_layout(title='Number of Inliers and Outliers')

# Apply highlight_outliers function to entire DataFrame and display with red rows
styled_data = data.style.apply(highlight_outliers, axis=1)

# Convert styled_data to a DataFrame
df = styled_data.data

# Create subplot with all three figures
fig = plotly.subplots.make_subplots(rows=3, cols=1, specs=[[{'type': 'scatter', 'rowspan': 1, 'colspan': 1}], 
                                                           [{'type': 'table', 'rowspan': 1, 'colspan': 1}], 
                                                           [{'type': 'domain', 'rowspan': 1, 'colspan': 1}]])

# Add traces to subplot
fig.add_trace(fig1['data'][0], row=1, col=1)
fig.add_trace(fig1['data'][1], row=1, col=1)
fig.add_trace(go.Table(header=dict(values=df.columns),
                       cells=dict(values=[df[col] for col in df.columns])),
              row=2, col=1)
fig.add_trace(fig2['data'][0], row=3, col=1)

# Update layout
fig.update_layout(title='Combined Visualizations')

# Save as HTML file
db_file_path = f"gs://{bucket_name_output}/{file_name_output}"
pio.write_html(fig, file="dashboard.html")

# set up the GCS client and upload the file to the specified path
client = storage.Client()
bucket = client.get_bucket(bucket_name_output)
blob = bucket.blob(file_name_output + "dashboard.html")
blob.upload_from_filename("dashboard.html")

