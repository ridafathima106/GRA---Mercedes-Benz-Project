import subprocess

# Install the plotly library using pip
subprocess.call(['pip', 'install', 'plotly'])
