from datetime import datetime, timedelta
from airflow import DAG
from airflow.contrib.operators.dataproc_operator import DataprocClusterCreateOperator, DataProcPySparkOperator, DataprocClusterDeleteOperator
from airflow.contrib.operators.gcs_to_bq import GoogleCloudStorageToBigQueryOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryCreateEmptyDatasetOperator
from airflow.providers.google.cloud.transfers.gcs_to_bigquery import GCSToBigQueryOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
import os


material_group = 'A688'
bucket_name = 'anomaly_data_detection'
file_name = 'Data Lake/MARA_Combined.csv'
bucket_name_output = 'anomaly_data_detection'
file_name_output = 'Output/'
project_id = 'gra-project-382403'
transform_script_path = 'gs://anomaly_data_detection/Scripts/transform_data.py'
dashboard_script_path = 'gs://anomaly_data_detection/Scripts/load_to_dashboard.py'
main = 'gs://anomaly_data_detection/Scripts/install_dependencies.py'

output_file = file_name_output + material_group + '.csv'

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2023, 3, 31),
    'catchup': False,
    'dataproc_pyspark_jars': 'gs://spark-lib/bigquery/spark-bigquery-latest_2.12.jar'
}



with DAG('anomalous_detection',
         default_args=default_args,
         schedule_interval=None) as dag:

    start_dag = DummyOperator(
        task_id='start_dag',
    )

    create_cluster = DataprocClusterCreateOperator(
        task_id='create_dataproc_cluster',
        project_id=project_id,
        cluster_name='outliers-detect-cluster',
        num_workers=2,
        zone='us-central1-a',
        master_machine_type='n1-standard-2',
        worker_machine_type='n1-standard-2',
        region='us-central1',
    )

    transform_data = DataProcPySparkOperator(
        task_id='transform_data',
        main=transform_script_path,
        job_name='transform-data-job',
        arguments=[
            '--material_group={}'.format(material_group),
            '--bucket_name={}'.format(bucket_name),
            '--file_name={}'.format(file_name),
            '--bucket_name_output={}'.format(bucket_name_output),
            '--file_name_output={}'.format(file_name_output)
        ],
        cluster_name='outliers-detect-cluster',
        region='us-central1',
    )

    create_dataset = BigQueryCreateEmptyDatasetOperator(
        task_id='create_dataset',
        dataset_id='outliers_data',
        project_id=project_id,
        location='US'
    )

    create_table = GoogleCloudStorageToBigQueryOperator(
        task_id='create_table',
        bucket=bucket_name,
        source_objects=[output_file],
        destination_project_dataset_table='{}.outliers_data.outliers_table'.format(project_id),
        schema_object=None,
        schema_fields=None,
        source_format='CSV',
        create_disposition='CREATE_IF_NEEDED',
        write_disposition='WRITE_TRUNCATE',
        field_delimiter='\t',
        skip_leading_rows=1,
        quote_character=None,
        allow_quoted_newlines=False,
        max_bad_records=None,
        ignore_unknown_values=False,
        encoding='UTF-8',
        delegate_to=None,
        schema_update_options=()
    )

    load_to_bigquery = GCSToBigQueryOperator(
        task_id='load_to_bigquery',
        bucket=bucket_name,
        source_objects=[output_file],
        destination_project_dataset_table='{}.outliers_data.outliers_table'.format(project_id),
        source_format='CSV',
        schema_fields=None,
        schema_object=None,
        write_disposition='WRITE_TRUNCATE',
        skip_leading_rows=1,
        field_delimiter='\t',
        max_bad_records=None,
        quote_character=None,
        allow_quoted_newlines=False,
        allow_jagged_rows=False,
        delegate_to=None
    )

    install_dependencies_task = DataProcPySparkOperator(
        task_id='install_dependencies_task',
        main=main,
        job_name='install-dependencies-job',
        cluster_name='outliers-detect-cluster',
        region='us-central1',
        dag=dag
    )


    create_report = DataProcPySparkOperator(
        task_id='create_report',
        main=dashboard_script_path,
        job_name='create-report-data-job',
        arguments=[
            '--material_group={}'.format(material_group),
            '--bucket_name_output={}'.format(bucket_name_output),
            '--file_name_output={}'.format(file_name_output)
        ],
        cluster_name='outliers-detect-cluster',
        region='us-central1',
    )

                                                                       
    delete_cluster = DataprocClusterDeleteOperator(
        task_id='delete_dataproc_cluster',
        project_id=project_id,
        cluster_name='outliers-detect-cluster',
        region='us-central1'
    )

    stop_dag = DummyOperator(
        task_id='stop_dag',
    )

start_dag >> create_cluster >> transform_data >> create_dataset >> create_table >> load_to_bigquery  >> install_dependencies_task >> create_report >> delete_cluster >> stop_dag
